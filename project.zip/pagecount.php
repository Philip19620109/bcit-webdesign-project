<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Page Counter</title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
		
	<body>
		
	  <?php
		$fp = fopen("counterlog.txt", "r");
		$count = fread($fp, 1024); fclose($fp);
		$count = $count + 1;
		$fp = fopen("counterlog.txt", "w");
		fwrite($fp, $count); 
		fclose($fp);
		?>
		
		<h1> This page has been visited <?=$count; ?> times. 
		</h1> &copy; <?php echo date("Y");?> BCIT
	  
	</body>
</html>